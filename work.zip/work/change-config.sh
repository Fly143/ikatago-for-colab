#!/bin/bash 

WEIGHT_NAME=$1
KATAGO_BACKEND=$2
CONFIG_FILE=./config/conf.yaml

CMD1="s|defaultBinName: .* # ENGINE_REPLACE_MARKER|defaultBinName: katago-$KATAGO_BACKEND # ENGINE_REPLACE_MARKER|g"
CMD2="s|defaultWeightName: .* # WEIGHT_REPLACE_MARKER|defaultWeightName: $WEIGHT_NAME # WEIGHT_REPLACE_MARKER|g"


sed -i -e "$CMD1" $CONFIG_FILE
sed -i -e "$CMD2" $CONFIG_FILE